// app/api/market/listings/cards/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    // latest 48 to keep it snappy
    const rows = await prisma.marketListing.findMany({
      orderBy: { createdAt: 'desc' },
      take: 48,
      select: {
        id: true,
        title: true,
        city: true,
        price: true,
        imageUrl: true,
        url: true,
        portal: true,
        externalId: true,
        createdAt: true,
      },
    });

    // group siblings by externalId (same property across portals)
    const extIds = Array.from(new Set(rows.map(r => r.externalId).filter(Boolean))) as string[];

    const siblings = extIds.length
      ? await prisma.marketListing.findMany({
          where: { externalId: { in: extIds } },
          select: { externalId: true, portal: true, url: true },
        })
      : [];

    const byExt = new Map<string, Array<{ portal: string; url: string }>>();
    for (const s of siblings) {
      if (!s.externalId) continue;
      if (!byExt.has(s.externalId)) byExt.set(s.externalId, []);
      byExt.get(s.externalId)!.push({ portal: s.portal, url: s.url });
    }

    const items = rows.map(r => {
      const portals = r.externalId ? (byExt.get(r.externalId) ?? [{ portal: r.portal, url: r.url }])
                                   : [{ portal: r.portal, url: r.url }];
      return {
        id: r.id,
        title: r.title || '—',
        city: r.city || null,
        price: r.price ?? null,
        imageUrl: r.imageUrl || null,
        portalsCount: portals.length,
        portals,              // [{portal,url}, ...]
        sourceUrl: r.url,
        createdAt: r.createdAt,
      };
    });

    return NextResponse.json({ items });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'cards failed' }, { status: 500 });
  }
}