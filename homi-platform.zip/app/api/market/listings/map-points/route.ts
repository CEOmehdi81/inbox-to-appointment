// app/api/market/listings/map-points/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const rows = await prisma.marketListing.findMany({
      where: { latitude: { not: null }, longitude: { not: null } },
      orderBy: { createdAt: 'desc' },
      take: 600,
      select: { id: true, latitude: true, longitude: true, title: true, city: true, price: true },
    });

    const points = rows.map(r => ({
      id: r.id,
      lat: Number(r.latitude),
      lng: Number(r.longitude),
      label: [r.title, r.city, r.price != null ? `${r.price} €` : null]
        .filter(Boolean)
        .join(' · '),
      size: r.price != null ? Math.min(3, Math.max(1, Math.round(Number(r.price) / 500))) : 1,
    }));

    return NextResponse.json({ points });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? 'map-points failed' }, { status: 500 });
  }
}